importClass(Packages.com.tivoli.am.fim.trustserver.sts.utilities.IDMappingExtUtils);
importClass(Packages.com.tivoli.am.fim.trustserver.sts.utilities.OAuthMappingExtUtils);
importClass(Packages.com.tivoli.am.fim.trustserver.sts.utilities.SignHelper);
importClass(Packages.com.ibm.security.access.user.UserLookupHelper);
importClass(Packages.com.ibm.security.access.HttpClient);

    IDMappingExtUtils.traceString("CIAM - PVCB - ROPC.JS flow starts");

    //Get username & password from the request
    var username = stsuu.getContextAttributes().getAttributeValueByName("username");
    var password = stsuu.getContextAttributes().getAttributeValueByName("password");

    // Salt parameter
    let iter = 27500;
    let keylength = 32; 
    let alg = "SHA256";

    IDMappingExtUtils.traceString("CIAM - PVCB : " + username);

    /**
     * This is an example of how you could verify the username and password with an
     * user registry before the access token is generated, therefore preventing
     * the scenario where access tokens are created for invalid users and stored in
     * the cache with no way to remove them till they expire.
     *
     * A prerequisite for using this example is configuring an ldap configuration
     * in ldapcfg.yml and associated ldap server connection in storage.yml
     * 
     * This example is the default method for verifying the username and password.
     * To enable this example, change the "ropc_registry_validation" variable 
     * to "true".
     */

    // Assuming there is ldap configuration name "user_registry" in ldapcfg.yml
    var userLookupHelper = new UserLookupHelper("ciam_svd");
    var attrUtil = new LdapAttributeUtil("ciam_svd");

    /**
     * CIAM PVCB - UserLookupHelper - Throw exception if LDAP server is down/unavailable
     */
    if(!userLookupHelper.isReady()) {
        IDMappingExtUtils.traceString("CIAM - PVCB - Throw exception - UserLookupHelper LDAP Connection Error");
        OAuthMappingExtUtils.throwSTSCustomUserMessageException("LDAP Connection Error", 500);
    }

    /**
     * CIAM PVCB - LdapAttributeUtil - Throw exception if LDAP server is down/unavailable
     */
    if(!attrUtil.isReady()) {
        IDMappingExtUtils.traceString("CIAM - PVCB - Throw exception - LdapAttributeUtil LDAP Connection Error");
        OAuthMappingExtUtils.throwSTSCustomUserMessageException("LDAP Connection Error", 500);
    }

    /**
     * Assuming the users has distinguished name pattern:
     * pvbUserUUID=<username>,ou=users,ou=retail,ou=customers,dc=pvb,dc=vn
     */
    var user = userLookupHelper.getUser(username);

    //var user = userLookupHelper.getUserByNativeId("uid=" + username + ",ou=users,ou=retail,ou=customers,dc=pvb,dc=vn");
    if (user.hasError()) { // check for error
        /**
         * This is the recommended way to check the error and logging it
         */
        IDMappingExtUtils.traceString("CIAM - PVCB - Throw exception - getUserByNativeId failed with error: " + user.getErrMessage());
        OAuthMappingExtUtils.throwSTSException("Unable to authenticate user." + user.getErrMessage());
    } 
    IDMappingExtUtils.traceString("CIAM - PVCB : " + JSON.stringify(user.getNativeId()));

    /**
     * Populate user metadata in the case of successful authentication
     * The metadata serve as credential attributes that can be used for grant enrichment
     * The metadata at least should contain 'uid' claim or any claim indicated in 'subject_attribute_name'
     * under provider.yml 'authentication' stanza as this will be used as the token 'sub' claim 
     */
    IDMappingExtUtils.traceString("Authentication is successful.");

    var pvbUserKCPwd = user.getAttribute("pvbUserKCPwd");
    //1st time login flow - Keycloak DB password validation
    if(pvbUserKCPwd != null) {
        validateAccountStatus();
        validateKCDBPwd(password, pvbUserKCPwd);
    }  else {
        //Login as CIAM users
        //var userPassword = user.getAttribute("userPassword");
        validateUserPassword(password);
    }
    
    //Adding userData parameters
    userData.uid = username;
    userData.given_name = user.getAttribute("givenName");
    userData.family_name = user.getAttribute("sn");
    userData.phoneNumber = user.getAttribute("homePhone");
    userData.email = user.getAttribute("mail");
    userData.cif = user.getAttribute("pvbUserCIF");
    userData.uuid = user.getAttribute("pvbUserUUID");
    userData.lastLoginTime = user.getAttribute("ibm-latestBindTimestamp");
    userData.pwdChangedTime = user.getAttribute("pwdChangedTime");
    userData.pwdFailureTime = user.getAttribute("pwdFailureTime");
    userData.preferred_username = username;

    IDMappingExtUtils.traceString("CIAM - PVCB - ROPC.JS flow ends");

/*
 * validateAccountStatus() method validates pvbUserStatus & ibm-pwdAccountLocked parameters.
 * This method throws exception if pvbUserStatus/ibm-pwdAccountLocked parameter set it as true.
 */
function validateAccountStatus() {
    var pvbUserStatus = user.getAttribute("pvbUserStatus");
    var pwdAccountLocked = user.getAttribute("ibm-pwdAccountLocked");
    
    IDMappingExtUtils.traceString("Keycloak DB user account status : " + pvbUserStatus);
    IDMappingExtUtils.traceString("ibm-pwdAccountLocked : " + pwdAccountLocked);

    //Validate account status
    if(pvbUserStatus != null && pvbUserStatus == "true"){
        IDMappingExtUtils.traceString("CIAM - PVCB Throw exception - Account locked");
        OAuthMappingExtUtils.throwSTSCustomUserMessageException("Account locked", 401, "account_locked");
    }

    //Validate if password reset by admin
    if(pwdAccountLocked != null && pwdAccountLocked == "true"){
        IDMappingExtUtils.traceString("CIAM - PVCB Throw exception - Account disabled");
        OAuthMappingExtUtils.throwSTSCustomUserMessageException("Account disabled", 401, "account_locked");
    }
}

/**
 * validateKCDBPwd() method 
 * 
 * @param password 
 */
function validateKCDBPwd(password, pvbUserKCPwd){
    //Parse pvbUserKCPwd as JSON data
    var pvbUserKCPwdJson = JSON.parse(pvbUserKCPwd);

    //Get value field
    var pvbUserKCPwdValue = pvbUserKCPwdJson.value;
    
    //Get salt parameter field
    var pvbUserKCPwdSalt = pvbUserKCPwdJson.salt;

    //Generate hash using Signing helper 
    var encodedHash = StringSigningHelper.calculatePBKDF2Hash(password, pvbUserKCPwdSalt, iter, keylength, alg);

    //Validate Keycloak DB password
    if(pvbUserKCPwdValue != encodedHash){
        IDMappingExtUtils.traceString("CIAM - PVCB Throw exception - Invalid Keycloak DB password");
        OAuthMappingExtUtils.throwSTSCustomUserMessageException("Invalid Credentials", 401, "invalid_credentials");
    } else { //Valid Keycloak DB passed in the request
        
        //Set userPassword attribute for user.
        var setUserPassword = attrUtil.setAttributeValue(user.getNativeId(), "userPassword", password);

        //Set userPassword failed
        if(setUserPassword.hasError()){
            IDMappingExtUtils.traceString("CIAM - PVCB Throw exception - Set userPassword failed");
            OAuthMappingExtUtils.throwSTSCustomUserMessageException("Unable to set password in CIAM", 500, "invalid_credentials");
        }

        //Unset pvbUserKCPwd attribute from user.
        var removePvbserKCPwd = attrUtil.removeAttribute(user.getNativeId(), "pvbUserKCPwd", pvbUserKCPwd);

        //Unset pvbUserKCPwd failed
        if(removePvbserKCPwd.hasError()){
            IDMappingExtUtils.traceString("CIAM - PVCB Throw exception - Unset pvbUserKCPwd failed");
            OAuthMappingExtUtils.throwSTSCustomUserMessageException("Unable to remove pvbUserKCPwd attribute", 500, "Invalid Credentials");
        }

        //PwdReset based on UUID
        var uuid = user.getAttribute("pvbUserUUID");
        IDMappingExtUtils.traceString("User account UUID : " + uuid);

        //Url parameter
        var url = "http://ciam-user-management.app-cdsvk-ciam-user-management.svc/api/v1/ciam/users/"+uuid;
        //IDMappingExtUtils.traceString("pwd_reset API Url : " + url);

        //Set bearer token
        var resetHeader = new Headers();
        resetHeader.addHeader("x-fapi-interaction-id", "b63a3a0b-3ed4-4931-bd1f-713cdafccacf");
        resetHeader.addHeader("Content-Type", "application/json");

        //Set request body
        var resetPayload = {"pwd_reset":false};

        //use string as payload
        var resetResponse = HttpClientV2.httpPut(url, resetHeader, JSON.stringify(resetPayload), null, 
            null, null, null, null, null, null, 5, true, null);

        if (resetResponse.hasError()) {
            // handle error...
            IDMappingExtUtils.traceString("pwd_reset API failed with : " + resetResponse.getError());
            OAuthMappingExtUtils.throwSTSCustomUserMessageException("Failed to connect to PwdReset API", 500, "invalid_credentials");
        } else {
            // process response
            IDMappingExtUtils.traceString("pwd_reset API response : " + resetResponse.getBody());
            IDMappingExtUtils.traceString("pwd_reset API status code : " + resetResponse.getCode());

            //Throw exception if status code other than 200
            if(resetResponse.getCode() != 200){
                OAuthMappingExtUtils.throwSTSCustomUserMessageException("Unable to set PwdReset flag", 500, "invalid_credentials");
            }
        }

        //Validate pvbUserAction contains value UPDATE_PASSWORD
        var pvbUserAction = user.getAttribute("pvbUserAction");
        IDMappingExtUtils.traceString("Keycloak DB user action : " + pvbUserAction);

        //Validate migrated password is expired - KC DB
        if(pvbUserAction == "UPDATE_PASSWORD") {

            //Set pwdReset flag for user.
            var setPwdReset = attrUtil.setAttributeValue(user.getNativeId(), "pwdReset", true);

            //Set pwsReset flag failed
            if(setPwdReset.hasError()){
                IDMappingExtUtils.traceString("CIAM - PVCB - Throw exception - Set userPassword failed");
                OAuthMappingExtUtils.throwSTSCustomUserMessageException("PwdReset failed", 500, "invalid_credentials");
            }

            IDMappingExtUtils.traceString("CIAM - PVCB Throw exception - User password expired.");
            OAuthMappingExtUtils.throwSTSCustomUserMessageException("Password Reset", 401, "Invalid Credentials");
        }
    }
}

function validateUserPassword(password){

    //User attributes.
    var attributes = attrUtil.getAttributeValue(user.getNativeId(), ["pwdReset", "pwdChangedTime", "pwdAccountLockedTime", "ibm-pwdAccountLocked"]); 
    let attributeList = attributes.getAttributes();

    //check the password
    var userAuth = user.authenticate(password);
    
    //Authentication fails
    if(!userAuth) { 
        var errorMsg = user.getErrMessage();
        IDMappingExtUtils.traceString("CIAM - PVCB Exception - failed to authenticate user : " + user.getNativeId());
        IDMappingExtUtils.traceString("CIAM - PVCB Exception - authentication failure reason : " + errorMsg);

        //Validate error message - contains `Invalid Credentials`
        if(errorMsg.includes("Invalid Credentials")) {
            OAuthMappingExtUtils.throwSTSCustomUserMessageException("Invalid Credentials", 401, "invalid_credentials");
        } 

        // Calculate pwdChangedTime diff
        let pwdChangedTimeAttribute = attributeList.get("pwdChangedTime")

        // Get pwdReset value only, if attribute associated with the user.
        if(pwdChangedTimeAttribute != null){   
            //formatted timestamp
            let pwdChangedTimeAttributeValue = pwdChangedTimeAttribute.get()
                    .replace(/(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})\.(\d+)/, '$1-$2-$3T$4:$5:$6.$7');
            const pwdChangedTimestamp = Date.parse(pwdChangedTimeAttributeValue);
            //IDMappingExtUtils.traceString("Password changed timestamp - Date: " + pwdChangedTimestamp);
        
            //Current timestamp
            const currentDate = new Date().getTime();

            //Calculate time difference
            const diffDays = Math.round(Math.abs((currentDate - pwdChangedTimestamp)/(1000*60*60*24)));

            //Throw exception if password changed time is greater than 180
            if(diffDays >= 180){
                IDMappingExtUtils.traceString("CIAM - PVCB Throw exception - Password expired.");
                OAuthMappingExtUtils.throwSTSCustomUserMessageException("Password expired", 401, "Invalid Credentials");
            }
        }

        //If pwdReset attribute is true, throw exception as Password Reset.
        let pwdResetAttribute = attributeList.get("pwdReset")

        //Get pwdReset value only, if attribute associated with the user.
        let pwdResetAttributeValue = null;
        if(pwdResetAttribute != null){
            pwdResetAttributeValue = pwdResetAttribute.get();
        }
        IDMappingExtUtils.traceString("pwdReset : " + pwdResetAttributeValue);

        if( pwdResetAttributeValue != null & pwdResetAttributeValue == "true"){
            IDMappingExtUtils.traceString("CIAM - PVCB Throw exception - Password Reset.");
            OAuthMappingExtUtils.throwSTSCustomUserMessageException("Password Reset", 401, "Invalid Credentials");
        }

        //Validate Account locked using pwdAccountLockedTime
        let pwdAccountLockedTime = attributeList.get("pwdAccountLockedTime");
        //Get pwdAccountLockedTime value only, if attribute associated with the user.
        let pwdAccountLockedTimeValue = null;

        if(pwdAccountLockedTime != null){
            pwdAccountLockedTimeValue = pwdAccountLockedTime.get();
        }
        IDMappingExtUtils.traceString("pwdAccountLockedTime : " + pwdAccountLockedTimeValue);

        if(pwdAccountLockedTimeValue != null){
            IDMappingExtUtils.traceString("CIAM - PVCB Throw exception - Account locked.");
            OAuthMappingExtUtils.throwSTSCustomUserMessageException("Account locked", 401, "Invalid Credentials");
        }

        //Validate Account disabled using ibm-pwdAccountLocked
        let ibmPwdAccountLocked = attributeList.get("ibm-pwdAccountLocked");
        //Get ibm-pwdAccountLocked value only, if attribute associated with the user.
        let ibmPwdAccountLockedValue = null;

        if(ibmPwdAccountLocked != null){
            ibmPwdAccountLockedValue = ibmPwdAccountLocked.get();
        }
        IDMappingExtUtils.traceString("ibm-pwdAccountLocked : " + ibmPwdAccountLockedValue);

        if(ibmPwdAccountLockedValue != null){
            IDMappingExtUtils.traceString("CIAM - PVCB Throw exception - Account disabled.");
            OAuthMappingExtUtils.throwSTSCustomUserMessageException("Account disabled", 401, "Invalid Credentials");
        }
        
        OAuthMappingExtUtils.throwSTSCustomUserMessageException(user.getErrMessage(), 401, "invalid_credentials");
    }
}